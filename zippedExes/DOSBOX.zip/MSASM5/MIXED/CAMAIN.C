
extern int Power2(int,int);

main()
{
	printf("3 times 2 to the power of 5 is %d\n", Power2(3,5));
}

